@echo off
chcp 65001 >nul
cd /d "%~dp0"
title IPHub
echo.
echo  Iniciando IPHub...
echo.

where node >nul 2>&1
if errorlevel 1 (
  echo  ERROR: Node.js no esta instalado.
  echo  Descargalo de https://nodejs.org y reinicia.
  pause
  exit /b 1
)

if not exist "node_modules\" (
  echo  Primera vez: instalando dependencias...
  call npm install
  if errorlevel 1 (
    echo  Fallo npm install
    pause
    exit /b 1
  )
)

echo  Servidor en http://127.0.0.1:3001
echo  Se abrira el navegador en 2 segundos...
echo  NO CIERRES esta ventana.
echo.

start "" cmd /c "timeout /t 2 /nobreak >nul & start http://127.0.0.1:3001"

node start.js
echo.
echo  El servidor se detuvo.
pause
