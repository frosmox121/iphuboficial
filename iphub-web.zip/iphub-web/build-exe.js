// Compila IPHub para Windows SIN electron-builder.
// electron-builder falla en muchas PCs con "symbolic link" / winCodeSign
// si no hay Modo desarrollador o administrador. @electron/packager no firma
// ni extrae esos enlaces, así que el build termina igual.
const { spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const root = __dirname;
const dir = path.join(root, 'agent');
const win = process.platform === 'win32';
process.chdir(dir);

function run(cmd) {
  const r = spawnSync(cmd, { stdio: 'inherit', shell: true, env: { ...process.env, CSC_IDENTITY_AUTO_DISCOVERY: 'false' } });
  return r.status == null ? 1 : r.status;
}

console.log('\n[1/3] Dependencias del monitor (electron + packager)…\n');
if (run('npm install --include=dev electron@31 @electron/packager --no-fund --no-audit') !== 0) {
  console.error('\nERROR: no se pudieron instalar electron y @electron/packager. Revisá internet y volvé a ejecutar.');
  process.exit(1);
}

console.log('\n[2/3] Armando IPHub.exe (sin firma, sin enlaces simbólicos)…\n');
const pack = win
  ? 'npx @electron/packager . IPHub --platform=win32 --arch=x64 --out=dist --overwrite --executable-name=IPHub --asar'
  : 'npx @electron/packager . IPHub --platform=win32 --arch=x64 --out=dist --overwrite --executable-name=IPHub --asar';
if (run(pack) !== 0) {
  console.error('\nFalló el empaquetado. El mensaje de arriba es el error real.');
  process.exit(1);
}

const appDir = path.join(dir, 'dist', 'IPHub-win32-x64');
const exe = path.join(appDir, 'IPHub.exe');
if (!fs.existsSync(exe)) {
  console.error('\nNo apareció dist/IPHub-win32-x64/IPHub.exe');
  process.exit(1);
}

const dest = path.join(root, 'public', 'download');
fs.mkdirSync(dest, { recursive: true });
const zipPath = path.join(dest, 'IPHub-Windows.zip');
try { fs.rmSync(zipPath, { force: true }); } catch (_) {}

console.log('\n[3/3] Comprimiendo para descargar desde la página…\n');
let zipped = false;
if (win) {
  zipped = run(`powershell -NoProfile -Command "Compress-Archive -Path '${appDir}\\*' -DestinationPath '${zipPath}' -Force"`) === 0 && fs.existsSync(zipPath);
} else {
  zipped = run(`cd "${appDir}" && zip -r "${zipPath}" .`) === 0 && fs.existsSync(zipPath);
}
if (!zipped) {
  console.log('No se pudo crear el zip automático. Igual podés usar la carpeta ya compilada.');
}

console.log('\n========================================');
console.log(' LISTO');
console.log(' Ejecutá: agent\\dist\\IPHub-win32-x64\\IPHub.exe');
if (fs.existsSync(zipPath)) console.log(' Descarga web: public\\download\\IPHub-Windows.zip');
console.log(' Descomprimí el zip y abrí IPHub.exe (tiene que quedar junto a la carpeta resources).');
console.log('========================================\n');
