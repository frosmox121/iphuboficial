@echo off
cd /d "%~dp0"
set "PATH=%PATH%;%ProgramFiles%\nodejs;%ProgramFiles(x86)%\nodejs;%LOCALAPPDATA%\Programs\nodejs"
where node >nul 2>&1
if errorlevel 1 (
  echo Node.js no esta instalado o no esta en el PATH.
  echo Instalar desde https://nodejs.org y volver a abrir este archivo.
  pause
  exit /b 1
)
node build-exe.js
if errorlevel 1 (
  echo.
  echo No se pudo compilar. Mira el mensaje de arriba.
  pause
  exit /b 1
)
echo.
echo Listo. Abri agent\dist\IPHub-win32-x64\IPHub.exe
pause
